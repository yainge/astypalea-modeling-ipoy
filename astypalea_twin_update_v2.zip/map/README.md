# Astypalea Interactive Energy & Mobility Map

Interactive web map for Astypalea island, Greece — part of the [Smart Sustainable Island](https://smartastypalea.gov.gr/) initiative.

## What the map shows

| Layer | Data quality | Source |
|-------|-------------|--------|
| Island boundary | Real | OpenStreetMap |
| Road network | Real | OpenStreetMap |
| Solar PV park (3.5 MW) | Real values, ~position | PPC Renewables press release, Apr 2022 |
| Battery storage (14.12 MWh) | Real values, ~position | PPC Renewables press release, Apr 2022 |
| Diesel thermal plant (~4.5 MW) | Estimated capacity & position | HEDNO island grid literature |
| Distribution substations | Estimated positions & capacity | HEDNO/academic literature on island grid topology |
| EV charging stations | Documented locations | astyMOVE project documentation |
| astyBUS route | Documented route | astyMOVE / Interreg Europe good practice report |
| Road congestion | **Modelled** | Seasonal factors from project documentation |
| Demand heatmap | **Modelled** | OSM buildings + 7 GWh/year HEDNO baseline |

## Build

```bash
cd map/
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

python scripts/fetch_osm.py          # ~30s; writes to data/osm/ (gitignored)
python scripts/build_energy_data.py
python scripts/build_mobility_data.py
python scripts/build_demand_zones.py
python scripts/plot_map.py           # writes docs/map_astypalea.html

open docs/map_astypalea.html
```

## Data sources

- **OpenStreetMap** — island boundary, roads, buildings, POIs
- **PPC Renewables** — solar park + BESS specifications (press releases 2022)
- **HEDNO/DEDDIE** — distribution network baseline; hourly load data from Aalborg MSc thesis (2019)
- **astyMOVE / SEAT:CODE Giravolta** — EV charging locations, bus route (Interreg Europe 2024)
- **ENTSO-E / Greek Census 2021** — background statistics

## Known limitations

- Demand and congestion layers are **modelled estimates**, not real-time measurements. Calibrated to the 7 GWh/year island baseline (HEDNO 2014–2015).
- Substation positions are approximate (±500m), derived from published grid topology descriptions.
- The solar park and BESS position is approximate (±200m), placed in the Maltezana/Analipsi area per PPC documentation.
- OSM coverage of Astypalea is good for roads and the town center, but building footprints may be incomplete in rural areas.

## Digital twin + PPC hybrid station (Phase 2)

`docs/twin_astypalea.html` is a 3D "digital twin" view built with [MapLibre GL JS](https://maplibre.org/) (open source, no API key):

- **3D buildings** coloured by settlement density (buildings within 250 m), a density heatmap, and settlement labels with building counts.
- **PPC Renewables hybrid station** (3.53 MW PV, 14.12 MWh battery) near Maltezana, with glowing animated energy flows to Maltezana, the airport and Chora (routed along roads as a stand-in for 20 kV feeders), plus the diesel station's flow to Chora.
- **Plant dashboard**: click the solar marker for a schematic model, live simulated readouts, a 24-hour dispatch chart and a check of PPC's "over 80%" claim against real HEDNO demand.
- Day (summer peak / spring / winter), operating mode (battery-led / diesel standby) and an hour slider drive the whole scene.
- **With / without the plant** switch: without it, the plant shows as "Not built", the solar lines turn into grey planned connections, and the diesel station supplies everything.
- **Analysis dashboard** (📊 button): before/after KPIs (diesel MWh, renewable share, CO2, fuel litres, fuel cost, diesel-free hours), source donuts, CO2 bars, month-by-month bars, a with/without day comparison, renewable share by month and plain-language takeaways. Fuel and cost assumptions are in `hybrid_plant_spec.json`.

Build (after the steps above):

```bash
python scripts/build_hybrid_plant.py   # simulate PV + battery against ipoy hourly demand
python scripts/build_settlements.py    # building density, heights, settlement clusters
python scripts/build_twin.py           # writes docs/twin_astypalea.html
```

Basemaps are keyless Esri tiles (satellite / dark / street) and AWS terrain tiles. Plant specs and modelling assumptions live in `data/energy/hybrid_plant_spec.json`.

Data fixes (Nov 2026): most asset coordinates in `energy_assets.csv`, `substations.csv` and `ev_charging_stations.csv` were offshore (0.1-5.7 km into the sea). They were moved onto land using OSM building clusters and the airport's published coordinates; each changed row says so in `notes`. The Vathi substation and charger are still unknown and are skipped by the twin. `build_energy_data.py` now warns about points more than ~200 m outside the island.
