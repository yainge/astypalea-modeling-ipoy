"""Simulate the PPC hybrid station (PV + battery) against real Astypalea demand.

Reads:  data/energy/hybrid_plant_spec.json
        ../ipoy/data/processed/astypalea_hourly_actual.csv   (real HEDNO hourly demand)
        data/energy/load_profiles.csv                         (fallback if the ipoy file is missing)
Writes: data/energy/hybrid_plant_sim.json

This is a SIMPLE rule-based simulation for visualisation, not a dispatch optimisation:
  1. Solar serves demand first.
  2. Surplus solar charges the battery (up to 8 MW and the energy limit); the rest is curtailed.
  3. A deficit is covered by the battery, then by diesel.
Two operating modes are reported:
  A  "battery_grid_forming": diesel runs only when solar + battery cannot cover demand.
  B  "one_diesel_always_on": one diesel unit always runs at minimum load (0.33 MW) for grid stability.
Solar output is a clear-sky shape scaled to the stated 6.55 GWh/year, so cloudy days are not captured.

Usage (from map/):  python scripts/build_hybrid_plant.py
"""

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

SCRIPTS_DIR = Path(__file__).parent
BASE_DIR = SCRIPTS_DIR.parent
ENERGY_DIR = BASE_DIR / "data" / "energy"
SPEC_PATH = ENERGY_DIR / "hybrid_plant_spec.json"
DEMAND_PATH = BASE_DIR.parent / "ipoy" / "data" / "processed" / "astypalea_hourly_actual.csv"
FALLBACK_PATH = ENERGY_DIR / "load_profiles.csv"
OUT_PATH = ENERGY_DIR / "hybrid_plant_sim.json"

LAT, LON = 36.58, 26.39


def load_demand():
    """Return a DataFrame with columns t_utc (UTC timestamps) and load_mw, one row per hour."""
    if DEMAND_PATH.exists():
        df = pd.read_csv(DEMAND_PATH, usecols=["timestamp_utc", "demand_mw"])
        df["t_utc"] = pd.to_datetime(df["timestamp_utc"], utc=True)
        df = df.rename(columns={"demand_mw": "load_mw"}).dropna(subset=["load_mw"])
        df = df.sort_values("t_utc").drop_duplicates("t_utc")
        # Keep the most recent 365 days so every month appears once
        end = df["t_utc"].max()
        df = df[df["t_utc"] > end - pd.Timedelta(days=365)]
        source = "HEDNO hourly operations reports (ipoy/data/processed/astypalea_hourly_actual.csv)"
    else:
        print(f"  NOTE: {DEMAND_PATH} not found, using synthetic load_profiles.csv")
        lp = pd.read_csv(FALLBACK_PATH)
        start = pd.Timestamp("2025-01-01 00:00", tz="Europe/Athens")
        t_local = start + pd.to_timedelta(lp["hour_of_year"] - 1, unit="h")
        df = pd.DataFrame({"t_utc": t_local.dt.tz_convert("UTC"), "load_mw": lp["load_mw"]})
        source = "Synthetic profile (data/energy/load_profiles.csv)"
    df = df[["t_utc", "load_mw"]].reset_index(drop=True)
    df["load_mw"] = df["load_mw"].clip(lower=0)
    df["t_local"] = df["t_utc"].dt.tz_convert("Europe/Athens")
    return df, source


def sun_elevation_sin(t_utc: pd.Series) -> np.ndarray:
    """Sine of solar elevation at the middle of each hour (NOAA approximation)."""
    t = t_utc + pd.Timedelta(minutes=30)
    doy = t.dt.dayofyear.values
    hour = t.dt.hour.values + t.dt.minute.values / 60
    g = 2 * math.pi / 365 * (doy - 1 + (hour - 12) / 24)
    decl = (0.006918 - 0.399912 * np.cos(g) + 0.070257 * np.sin(g) - 0.006758 * np.cos(2 * g)
            + 0.000907 * np.sin(2 * g) - 0.002697 * np.cos(3 * g) + 0.00148 * np.sin(3 * g))
    eqtime = 229.18 * (0.000075 + 0.001868 * np.cos(g) - 0.032077 * np.sin(g)
                       - 0.014615 * np.cos(2 * g) - 0.040849 * np.sin(2 * g))
    solar_time = hour * 60 + eqtime + 4 * LON          # minutes
    ha = np.radians(solar_time / 4 - 180)
    lat = math.radians(LAT)
    return np.sin(lat) * np.sin(decl) + np.cos(lat) * np.cos(decl) * np.cos(ha)


def pv_profile(df: pd.DataFrame, spec: dict) -> np.ndarray:
    """Hourly PV output (MW): clear-sky shape, scaled to monthly yields and the stated annual total."""
    pv_mw = spec["stated"]["pv_mw"]["value"]
    annual_mwh = spec["stated"]["annual_generation_gwh"]["value"] * 1000
    monthly = np.array(spec["assumptions"]["pv_monthly_kwh_per_kwp"]["value"], dtype=float)
    monthly *= (annual_mwh / pv_mw) / monthly.sum()        # rescale to the stated annual yield
    days_in_month = np.array([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
    daily_mwh = pv_mw * monthly / days_in_month             # MWh per day for each month

    shape = np.clip(sun_elevation_sin(df["t_utc"]), 0, None) ** 1.2
    day_key = df["t_local"].dt.date
    day_sum = pd.Series(shape).groupby(day_key.values).transform("sum").values
    month = df["t_local"].dt.month.values - 1
    pv = np.where(day_sum > 0, shape / np.where(day_sum > 0, day_sum, 1) * daily_mwh[month], 0.0)
    return np.minimum(pv, pv_mw)


def simulate(load: np.ndarray, pv: np.ndarray, spec: dict, diesel_floor: float) -> dict:
    a = spec["assumptions"]
    cap = spec["stated"]["battery_mwh"]["value"]
    p_ch = spec["stated"]["battery_charge_mw"]["value"]
    p_dis = a["battery_discharge_mw"]["value"]
    eta = math.sqrt(a["battery_roundtrip_eff"]["value"])
    soc_min = a["battery_soc_min"]["value"] * cap
    soc = a["battery_soc_start"]["value"] * cap

    n = len(load)
    out = {k: np.zeros(n) for k in ["pv_direct", "charge", "discharge", "diesel", "curtail", "soc"]}
    for i in range(n):
        diesel = min(diesel_floor, load[i])            # always-on unit (mode B only)
        residual = load[i] - diesel
        direct = min(pv[i], residual)
        surplus = pv[i] - direct
        deficit = residual - direct

        charge = min(surplus, p_ch, (cap - soc) / eta)
        soc += charge * eta
        curtail = surplus - charge

        discharge = min(deficit, p_dis, max(soc - soc_min, 0) * eta)
        soc -= discharge / eta
        diesel += deficit - discharge

        out["pv_direct"][i] = direct
        out["charge"][i] = charge
        out["discharge"][i] = discharge
        out["diesel"][i] = diesel
        out["curtail"][i] = curtail
        out["soc"][i] = soc / cap
    return out


def diesel_impacts(diesel_mwh, spec):
    a = spec["assumptions"]
    return {
        "co2_t": round(diesel_mwh * a["diesel_co2_t_per_mwh"]["value"], 0),
        "fuel_litres": round(diesel_mwh * a["diesel_litres_per_mwh"]["value"], -2),
        "fuel_cost_eur": round(diesel_mwh * a["diesel_cost_eur_per_mwh"]["value"], -2),
    }


def summarise(load, pv, res, spec):
    ef = spec["assumptions"]["diesel_co2_t_per_mwh"]["value"]
    demand = load.sum()
    diesel = res["diesel"].sum()
    out = {
        "renewable_share_pct": round(100 * (1 - diesel / demand), 1),
        "diesel_mwh": round(diesel, 0),
        "pv_direct_mwh": round(res["pv_direct"].sum(), 0),
        "battery_out_mwh": round(res["discharge"].sum(), 0),
        "pv_used_mwh": round(res["pv_direct"].sum() + res["discharge"].sum(), 0),
        "curtailed_mwh": round(res["curtail"].sum(), 0),
        "curtailed_pct_of_pv": round(100 * res["curtail"].sum() / max(pv.sum(), 1e-9), 1),
        "battery_full_cycles": round(res["discharge"].sum() / spec["stated"]["battery_mwh"]["value"], 0),
        "co2_avoided_t": round((demand - diesel) * ef, 0),
        "hours_diesel_off": int((res["diesel"] < 1e-6).sum()),
        "hours_total": int(len(load)),
    }
    out.update(diesel_impacts(diesel, spec))
    return out


def pick_days(df):
    daily = df.groupby(df["t_local"].dt.date)["load_mw"].agg(["sum", "count"])
    daily = daily[daily["count"] == 24]
    months = pd.to_datetime(pd.Series(daily.index)).dt.month.values

    def median_day(month_set):
        sub = daily[np.isin(months, month_set)]
        if sub.empty:
            return None
        return (sub["sum"] - sub["sum"].median()).abs().idxmin()

    return {
        "summer": ("Summer peak day", daily["sum"].idxmax()),
        "shoulder": ("Typical spring day", median_day([4, 5])),
        "winter": ("Typical winter day", median_day([12, 1, 2])),
    }


def r3(a):
    return [round(float(x), 3) for x in a]


def main():
    spec = json.loads(SPEC_PATH.read_text(encoding="utf-8"))
    df, source = load_demand()
    load = df["load_mw"].values
    pv = pv_profile(df, spec)
    floor = spec["assumptions"]["diesel_unit_min_mw"]["value"]

    modes = {
        "A": ("Battery forms the grid (diesel only when needed)", simulate(load, pv, spec, 0.0)),
        "B": ("One diesel unit always on at minimum load", simulate(load, pv, spec, floor)),
    }
    print(f"  Demand: {source}")
    print(f"  Period: {df['t_local'].min():%Y-%m-%d} to {df['t_local'].max():%Y-%m-%d} ({len(df)} hours)")
    print(f"  Demand {load.sum():.0f} MWh | PV potential {pv.sum():.0f} MWh")

    result = {
        "demand_source": source,
        "period": {"start": f"{df['t_local'].min():%Y-%m-%d}", "end": f"{df['t_local'].max():%Y-%m-%d}",
                   "hours": int(len(df))},
        "annual": {"demand_mwh": round(load.sum(), 0), "pv_potential_mwh": round(pv.sum(), 0), "modes": {},
                   "peak_mw": round(float(load.max()), 2),
                   "baseline": dict(diesel_impacts(load.sum(), spec), diesel_mwh=round(load.sum(), 0),
                                    label="Without the plant: diesel supplies everything")},
        "monthly": [],
        "days": {},
        "notes": [
            "Simulated, not measured: clear-sky solar scaled to PPC's stated 6.55 GWh/year, rule-based battery.",
            "Demand is HEDNO's hourly station output; missing weeks are skipped, so totals cover the hours available.",
            "CO2 avoided = demand served by solar/battery x assumed diesel emission factor.",
        ],
    }
    for key, (label, res) in modes.items():
        s = summarise(load, pv, res, spec)
        s["label"] = label
        result["annual"]["modes"][key] = s
        print(f"  Mode {key}: renewable share {s['renewable_share_pct']}% | diesel {s['diesel_mwh']:.0f} MWh "
              f"| curtailed {s['curtailed_pct_of_pv']}% | CO2 avoided {s['co2_avoided_t']:.0f} t")

    month_key = df["t_local"].dt.strftime("%Y-%m").values
    for m in sorted(set(month_key)):
        idx = month_key == m
        row = {"month": m, "hours": int(idx.sum()), "demand_mwh": round(load[idx].sum(), 0),
               "pv_mwh": round(pv[idx].sum(), 0), "peak_mw": round(float(load[idx].max()), 2)}
        for key, (_, res) in modes.items():
            row[f"share_{key}"] = round(100 * (1 - res["diesel"][idx].sum() / max(load[idx].sum(), 1e-9)), 1)
            row[f"pv_direct_{key}"] = round(res["pv_direct"][idx].sum(), 1)
            row[f"battery_{key}"] = round(res["discharge"][idx].sum(), 1)
            row[f"diesel_{key}"] = round(res["diesel"][idx].sum(), 1)
            row[f"curtail_{key}"] = round(res["curtail"][idx].sum(), 1)
        result["monthly"].append(row)

    # Same figures grouped by calendar month (Jan..Dec), for simple charts.
    # The data window starts and ends in October, so October combines both years.
    cal = df["t_local"].dt.month.values
    names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    days_in = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    result["calendar_months"] = []
    for mi in range(1, 13):
        idx = cal == mi
        if not idx.any():
            continue
        row = {"month": names[mi - 1], "hours": int(idx.sum()),
               "coverage_pct": round(100 * idx.sum() / (days_in[mi - 1] * 24), 0),
               "demand_mwh": round(load[idx].sum(), 1), "pv_mwh": round(pv[idx].sum(), 1),
               "avg_mw": round(float(load[idx].mean()), 2), "peak_mw": round(float(load[idx].max()), 2)}
        for key, (_, res) in modes.items():
            row[f"pv_direct_{key}"] = round(res["pv_direct"][idx].sum(), 1)
            row[f"battery_{key}"] = round(res["discharge"][idx].sum(), 1)
            row[f"diesel_{key}"] = round(res["diesel"][idx].sum(), 1)
            row[f"curtail_{key}"] = round(res["curtail"][idx].sum(), 1)
            row[f"share_{key}"] = round(100 * (1 - res["diesel"][idx].sum() / max(load[idx].sum(), 1e-9)), 1)
        result["calendar_months"].append(row)

    dates = df["t_local"].dt.date.values
    for key, (label, day) in pick_days(df).items():
        if day is None:
            continue
        idx = np.where(dates == day)[0]
        entry = {"label": label, "date": str(day), "load": r3(load[idx]), "pv": r3(pv[idx])}
        for mk, (_, res) in modes.items():
            entry[mk] = {k: r3(v[idx]) for k, v in res.items()}
        result["days"][key] = entry

    OUT_PATH.write_text(json.dumps(result, indent=1), encoding="utf-8")
    print(f"  -> {OUT_PATH}")


if __name__ == "__main__":
    print("Simulating hybrid station...")
    main()
    print("Done.")
