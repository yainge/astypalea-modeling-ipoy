"""Assemble the digital-twin page: docs/twin_astypalea.html

Reads (run the other build scripts first):
    data/osm/boundary_astypalea.geojson              fetch_osm.py
    data/mobility/roads_congestion_summer.geojson    build_mobility_data.py
    data/mobility/roads_congestion_winter.geojson    build_mobility_data.py
    data/mobility/ev_charging_stations.csv
    data/energy/substations.csv
    data/energy/energy_assets.csv
    data/energy/hybrid_plant_spec.json
    data/energy/hybrid_plant_sim.json                build_hybrid_plant.py
    data/twin/buildings_3d.geojson                   build_settlements.py
    data/twin/settlements.json                       build_settlements.py
Template:
    scripts/templates/twin_template.html
Writes:
    docs/twin_astypalea.html   (self-contained: data is embedded, opens by double-click)
    data/twin/energy_links.geojson, data/twin/bus_route_roads.geojson

Energy links and the bus route are routed along the OSM road network (shortest path),
as a stand-in for the real 20 kV feeders, whose routing is not published.

Usage (from map/):  python scripts/build_twin.py
"""

import csv
import heapq
import json
import math
from pathlib import Path

SCRIPTS_DIR = Path(__file__).parent
BASE_DIR = SCRIPTS_DIR.parent
DATA = BASE_DIR / "data"
TWIN_DIR = DATA / "twin"
TEMPLATE = SCRIPTS_DIR / "templates" / "twin_template.html"
OUT = BASE_DIR / "docs" / "twin_astypalea.html"

KX, KY = 89.5, 111.2   # km per degree lon / lat at 36.5 N


def read_json(path):
    if not path.exists():
        raise SystemExit(f"  ERROR: {path} not found. Run the earlier build scripts first (see map/README.md).")
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path):
    with open(path, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def rnd(coords, nd=5):
    if isinstance(coords[0], (int, float)):
        return [round(coords[0], nd), round(coords[1], nd)]
    return [rnd(c, nd) for c in coords]


def dist_km(a, b):
    return math.hypot((a[0] - b[0]) * KX, (a[1] - b[1]) * KY)


# ---------- island boundary / point-in-polygon ----------
def boundary_polys(boundary_fc):
    polys = []
    for f in boundary_fc["features"]:
        g = f["geometry"]
        polys += g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
    return polys


def in_ring(x, y, ring):
    inside = False
    for i in range(len(ring)):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % len(ring)]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            inside = not inside
    return inside


def on_island(polys, lon, lat):
    return any(in_ring(lon, lat, p[0]) for p in polys)


# ---------- road graph routing ----------
class RoadGraph:
    def __init__(self, roads_fc):
        self.adj = {}
        self.coords = {}
        for f in roads_fc["features"]:
            g = f["geometry"]
            lines = [g["coordinates"]] if g["type"] == "LineString" else g["coordinates"]
            for line in lines:
                a, b = self._key(line[0]), self._key(line[-1])
                length = sum(dist_km(line[i], line[i + 1]) for i in range(len(line) - 1))
                self.adj.setdefault(a, []).append((b, length, line))
                self.adj.setdefault(b, []).append((a, length, line[::-1]))
        self.nodes = list(self.adj)

    def _key(self, p):
        k = (round(p[0], 6), round(p[1], 6))
        self.coords[k] = p
        return k

    def nearest(self, p):
        return min(self.nodes, key=lambda k: dist_km(k, p))

    def route(self, start, end):
        """Shortest path along roads from point start to point end (lon, lat)."""
        s, t = self.nearest(start), self.nearest(end)
        best, prev = {s: 0.0}, {}
        heap = [(0.0, s)]
        while heap:
            d, u = heapq.heappop(heap)
            if u == t:
                break
            if d > best.get(u, 1e9):
                continue
            for v, w, line in self.adj[u]:
                nd = d + w
                if nd < best.get(v, 1e9):
                    best[v], prev[v] = nd, (u, line)
                    heapq.heappush(heap, (nd, v))
        if t not in prev and s != t:
            return [list(start), list(end)], dist_km(start, end)
        path, node = [], t
        while node != s:
            u, line = prev[node]
            path = line[:-1] + path if path else list(line)
            node = u
        coords = [list(start)] + path + [list(end)]
        length = sum(dist_km(coords[i], coords[i + 1]) for i in range(len(coords) - 1))
        return coords, length


def main():
    spec = read_json(DATA / "energy" / "hybrid_plant_spec.json")
    sim = read_json(DATA / "energy" / "hybrid_plant_sim.json")
    boundary = read_json(DATA / "osm" / "boundary_astypalea.geojson")
    roads_s = read_json(DATA / "mobility" / "roads_congestion_summer.geojson")
    roads_w_path = DATA / "mobility" / "roads_congestion_winter.geojson"
    roads_w = read_json(roads_w_path) if roads_w_path.exists() else roads_s
    buildings = read_json(TWIN_DIR / "buildings_3d.geojson")
    settlements = read_json(TWIN_DIR / "settlements.json")
    polys = boundary_polys(boundary)

    # Roads: one geometry, summer + winter congestion as properties
    same = len(roads_s["features"]) == len(roads_w["features"])
    road_feats = []
    for i, f in enumerate(roads_s["features"]):
        cw = roads_w["features"][i]["properties"].get("congestion") if same else f["properties"].get("congestion")
        hw = f["properties"].get("highway")
        hw = hw[0] if isinstance(hw, list) and hw else hw
        road_feats.append({"type": "Feature", "geometry": {"type": f["geometry"]["type"],
                           "coordinates": rnd(f["geometry"]["coordinates"])},
                           "properties": {"cs": f["properties"].get("congestion", 0.25), "cw": cw or 0.25,
                                          "hw": hw or "", "name": f["properties"].get("name") or ""}})
    graph = RoadGraph(roads_s)

    # Points on the island only (anything still offshore is reported and skipped)
    def points_from_csv(path, kind):
        out = []
        for r in read_csv(path):
            lon, lat = float(r["lon"]), float(r["lat"])
            if not on_island(polys, lon, lat):
                print(f"  WARN: '{r['name']}' is offshore ({lat}, {lon}) - skipped in the twin. Fix its coordinates in {path.name}.")
                continue
            props = {k: v for k, v in r.items() if k not in ("lat", "lon")}
            props["kind"] = kind
            out.append({"type": "Feature", "geometry": {"type": "Point", "coordinates": [lon, lat]}, "properties": props})
        return {"type": "FeatureCollection", "features": out}

    ev = points_from_csv(DATA / "mobility" / "ev_charging_stations.csv", "ev")
    subs = points_from_csv(DATA / "energy" / "substations.csv", "substation")
    assets = points_from_csv(DATA / "energy" / "energy_assets.csv", "asset")

    # Energy links from the plant, routed along roads
    plant = [spec["location"]["lon"], spec["location"]["lat"]]
    link_feats = []
    for link in spec["links"]:
        to = [link["to"]["lon"], link["to"]["lat"]]
        coords, km = graph.route(plant, to)
        link_feats.append({"type": "Feature", "geometry": {"type": "LineString", "coordinates": rnd(coords, 6)},
                           "properties": {"id": link["id"], "name": link["name"], "kind": "solar",
                                          "km": round(km, 2), "note": link.get("note", "")}})
        print(f"  Link plant -> {link['name']}: {km:.2f} km along roads")
    dl = spec["diesel_link"]
    coords, km = graph.route([dl["from"]["lon"], dl["from"]["lat"]], [dl["to"]["lon"], dl["to"]["lat"]])
    link_feats.append({"type": "Feature", "geometry": {"type": "LineString", "coordinates": rnd(coords, 6)},
                       "properties": {"id": "diesel", "name": dl["name"], "kind": "diesel", "km": round(km, 2),
                                      "note": dl.get("note", "")}})
    links = {"type": "FeatureCollection", "features": link_feats}

    # astyBUS route rebuilt along roads through its documented stops
    stops = [("Airport", 26.3758, 36.5799), ("Chora", 26.3525, 36.5490), ("Livadi", 26.3420, 36.5425),
             ("Pera Gialos", 26.3526, 36.5458), ("Maltezana", 26.3831, 36.5772)]
    bus_coords = []
    for (_, x1, y1), (_, x2, y2) in zip(stops, stops[1:]):
        seg, _ = graph.route([x1, y1], [x2, y2])
        bus_coords += seg if not bus_coords else seg[1:]
    bus = {"type": "FeatureCollection", "features": [
        {"type": "Feature", "geometry": {"type": "LineString", "coordinates": rnd(bus_coords)},
         "properties": {"name": "astyBUS Main Line", "stops": " -> ".join(s[0] for s in stops),
                        "note": "Routed along OSM roads through the documented stops."}}]}

    # Building centroids for the density heatmap
    pts = []
    for f in buildings["features"]:
        g = f["geometry"]
        ring = g["coordinates"][0] if g["type"] == "Polygon" else g["coordinates"][0][0]
        pts.append([round(sum(p[0] for p in ring) / len(ring), 5), round(sum(p[1] for p in ring) / len(ring), 5)])

    TWIN_DIR.mkdir(parents=True, exist_ok=True)
    (TWIN_DIR / "energy_links.geojson").write_text(json.dumps(links), encoding="utf-8")
    (TWIN_DIR / "bus_route_roads.geojson").write_text(json.dumps(bus), encoding="utf-8")

    data = {
        "spec": spec, "sim": sim, "settlements": settlements,
        "boundary": {"type": "FeatureCollection", "features": [
            {"type": "Feature", "properties": {}, "geometry": {
                "type": f["geometry"]["type"], "coordinates": rnd(f["geometry"]["coordinates"])}}
            for f in boundary["features"]]},
        "roads": {"type": "FeatureCollection", "features": road_feats},
        "buildings": buildings, "points": pts, "links": links, "bus": bus,
        "ev": ev, "substations": subs, "assets": assets,
    }
    html = TEMPLATE.read_text(encoding="utf-8")
    payload = json.dumps(data, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
    if "/*__TWIN_DATA__*/null" not in html:
        raise SystemExit("  ERROR: placeholder /*__TWIN_DATA__*/null missing from the template.")
    html = html.replace("/*__TWIN_DATA__*/null", payload)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(html, encoding="utf-8")
    print(f"  -> {OUT} ({OUT.stat().st_size / 1e6:.1f} MB)")
    print("  Open it by double-clicking the file (needs internet for map tiles and the MapLibre library).")


if __name__ == "__main__":
    print("Building digital twin page...")
    main()
    print("Done.")
