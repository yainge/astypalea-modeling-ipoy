"""Building density and settlement clusters for the digital twin.

Reads:  data/osm/buildings_astypalea.geojson   (from fetch_osm.py)
        data/energy/hybrid_plant_spec.json     (settlement names and centres)
Writes: data/twin/buildings_3d.geojson         (footprints + estimated height + local density)
        data/twin/settlements.json             (building count and share per settlement)

Heights: OSM has almost no height tags on Astypalea, so height is estimated
(building:levels x 3.2 m when tagged, otherwise 4.5-7 m by footprint size, churches 8 m).
Density = number of buildings within 250 m of each building.

Usage (from map/):  python scripts/build_settlements.py
"""

import json
import math
from pathlib import Path

import numpy as np

SCRIPTS_DIR = Path(__file__).parent
BASE_DIR = SCRIPTS_DIR.parent
OSM_DIR = BASE_DIR / "data" / "osm"
SPEC_PATH = BASE_DIR / "data" / "energy" / "hybrid_plant_spec.json"
OUT_DIR = BASE_DIR / "data" / "twin"

KX, KY = 89.5, 111.2          # km per degree of longitude / latitude at 36.5 N
DENSITY_RADIUS_KM = 0.25
SETTLEMENT_RADIUS_KM = 0.8


def outer_rings(geom):
    if geom["type"] == "Polygon":
        return [geom["coordinates"][0]]
    if geom["type"] == "MultiPolygon":
        return [poly[0] for poly in geom["coordinates"]]
    return []


def ring_area_m2(ring):
    xs = np.array([p[0] for p in ring]) * KX * 1000
    ys = np.array([p[1] for p in ring]) * KY * 1000
    return abs(np.dot(xs, np.roll(ys, 1)) - np.dot(ys, np.roll(xs, 1))) / 2


def to_float(v):
    try:
        return float(str(v).split(";")[0])
    except (TypeError, ValueError):
        return None


def estimate_height(props, area):
    levels = to_float(props.get("building:levels"))
    if levels:
        return round(levels * 3.2, 1)
    btype = str(props.get("building") or "")
    if btype in ("church", "chapel", "cathedral"):
        return 8.0
    return round(4.5 + min(area / 200.0, 1.0) * 2.5, 1)


def main():
    src = OSM_DIR / "buildings_astypalea.geojson"
    if not src.exists():
        print(f"  ERROR: {src} not found. Run fetch_osm.py first.")
        return
    spec = json.loads(SPEC_PATH.read_text(encoding="utf-8"))
    anchors = spec["settlements"]
    feats_in = json.loads(src.read_text(encoding="utf-8"))["features"]

    rows = []
    for f in feats_in:
        geom = f.get("geometry")
        if not geom:
            continue
        rings = outer_rings(geom)
        if not rings:
            continue
        pts = np.array([p for r in rings for p in r])
        cx, cy = pts[:, 0].mean(), pts[:, 1].mean()
        area = sum(ring_area_m2(r) for r in rings)
        rows.append((f, cx, cy, area))

    xy = np.array([[r[1] * KX, r[2] * KY] for r in rows])
    density = np.array([(np.hypot(*(xy - p).T) < DENSITY_RADIUS_KM).sum() - 1 for p in xy])
    dmax = max(int(density.max()), 1)

    ax = np.array([[a["lon"] * KX, a["lat"] * KY] for a in anchors])
    features, counts, members = [], {}, {}
    for (f, cx, cy, area), dens in zip(rows, density):
        d = np.hypot(*(ax - [cx * KX, cy * KY]).T)
        k = int(d.argmin())
        settlement = anchors[k]["name"] if d[k] <= SETTLEMENT_RADIUS_KM else "Rural / scattered"
        counts[settlement] = counts.get(settlement, 0) + 1
        members.setdefault(settlement, []).append((cx, cy))
        props = f.get("properties") or {}
        geom = f["geometry"]
        geom = {"type": geom["type"], "coordinates": json.loads(json.dumps(geom["coordinates"]),
                                                               parse_float=lambda s: round(float(s), 6))}
        features.append({
            "type": "Feature",
            "geometry": geom,
            "properties": {
                "h": estimate_height(props, area),
                "density": int(dens),
                "dn": round(min(dens / dmax, 1.0), 3),
                "settlement": settlement,
                "type": props.get("building") or "yes",
                "name": props.get("name") or "",
                "area_m2": round(area),
            },
        })

    total = len(features)
    settlements = []
    for a in anchors + [{"name": "Rural / scattered"}]:
        name = a["name"]
        n = counts.get(name, 0)
        if n == 0:
            continue
        pts = np.array(members[name])
        settlements.append({
            "name": name,
            "lat": a.get("lat", round(float(pts[:, 1].mean()), 5)),
            "lon": a.get("lon", round(float(pts[:, 0].mean()), 5)),
            "buildings": n,
            "share_pct": round(100 * n / total, 1),
            "rural": name == "Rural / scattered",
        })

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUT_DIR / "buildings_3d.geojson").write_text(
        json.dumps({"type": "FeatureCollection", "features": features}, separators=(",", ":")), encoding="utf-8")
    (OUT_DIR / "settlements.json").write_text(
        json.dumps({"total_buildings": total, "max_density": dmax, "settlements": settlements}, indent=1),
        encoding="utf-8")
    print(f"  {total} buildings | max density {dmax} within {int(DENSITY_RADIUS_KM * 1000)} m")
    for s in settlements:
        print(f"    {s['name']:<18} {s['buildings']:>4} buildings ({s['share_pct']}%)")
    print(f"  -> {OUT_DIR / 'buildings_3d.geojson'}")
    print(f"  -> {OUT_DIR / 'settlements.json'}")


if __name__ == "__main__":
    print("Building settlement density...")
    main()
    print("Done.")
